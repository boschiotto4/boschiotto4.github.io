# Android + ESP32 Daikin Control

## Architecture

Android app -> ESP32 (HTTP API over Wi-Fi) -> Tasmota IR Wi-Fi adapter (IRHVAC command) -> Daikin AC

## ESP32 firmware features

- Control AP created by ESP32:
  - SSID: ESP32-DAIKIN
  - Password: 12345678
- STA mode from ESP32 to IR adapter AP (configurable from Android)
- REST API endpoints:
  - GET /api/status (shows active_routine and routine_time_remaining_sec)
  - GET /api/send
  - GET /api/config/set
  - GET /api/routine/get (returns routines with duration_minutes)
  - GET /api/routine/set (accepts duration_minutes parameter)
  - GET /api/time/set
- NVS persistence for adapter config and routine
- Routine scheduler with temperature-based triggering and time-based sequencing
- Auto-transition between routines when duration expires
- Time source:
  - SNTP (when network allows internet)
  - Manual epoch sync from Android
- ESP32 internal temperature exposed in /api/status as esp32_temp_c
- Routine state tracking: current active routine, time remaining until next transition

## Android app location

- android-app/

The app contains three tabs:

- Config:
  - Set ESP32 host
  - Configure adapter SSID/password/IP/port
  - Read sensor data (temperature/humidity)
  - Sync ESP32 time
- Control:
  - Send immediate Daikin command
  - Set power/mode/temp/fan/swing
  - Refresh ESP32 status
- Routine:
  - Enable/disable up to 8 temperature-based routines
  - Configure trigger temperature (rises above / drops below)
  - Set routine duration in minutes (time to run before moving to next)
  - Set Daikin command profile (power/mode/temp/fan/swing)
  - Load/Save routines from/to ESP32
  - Monitor active routine and time remaining

## Build Android app

1. Open android-app in Android Studio.
2. Let Gradle sync.
3. Build and install the app on your phone.
4. Connect phone Wi-Fi to ESP32-DAIKIN.
5. Open app and keep host as 192.168.4.1.

## ESP32 API examples

### Send command now

GET /api/send?power=On&mode=Cool&temp=24&fan=Auto&swing_v=Off&swing_h=Off

### Configure adapter Wi-Fi and IP

GET /api/config/set?ssid=tasmota-513A92-6802&pass=&adapter_ip=192.168.4.1&adapter_port=80

### Set routine with duration

GET /api/routine/set?r0_en=1&r0_typ=2&r0_tt=28.0&r0_dur=180&r0_p=On&r0_m=Cool&r0_t=28&r0_f=Auto&r0_v=Off&r0_h=Off

Parameters:
- r0_en: enabled (0/1)
- r0_typ: trigger type (1=rises above, 2=drops below)
- r0_tt: trigger temperature (15.0-35.0)
- r0_dur: duration in minutes (5-1440)
- r0_p: power (On/Off)
- r0_m: mode (Cool/Heat/Fan/Dry/Auto)
- r0_t: target temperature (16-30)
- r0_f: fan (Auto/Quiet/Min/Med/Max)
- r0_v: swing vertical (On/Off/Auto)
- r0_h: swing horizontal (On/Off/Auto)

Repeat for r1_*, r2_*, etc. up to r7_* for 8 routines.

### Get current routines

GET /api/routine/get

Returns JSON array with duration field for each routine

### Manual time sync from Android

GET /api/time/set?epoch=1714118400

### Read status and ESP32 temperature

GET /api/status

## Notes

- ESP32 internal temperature is a chip sensor estimate, not room temperature.
- Routine triggering: temperature threshold with trigger type (rises above / drops below)
- Routine sequencing: when duration expires, automatically moves to next enabled routine
- Routine cycling: after routine 7, loops back to routine 0
- Scheduler uses ESP32 local clock (UTC in current firmware) for timing
- Time resolution: ±1 second (FreeRTOS 1000ms tick)
- For internet-free setup, press Sync Time in Android after connecting
- See ROUTINE_DURATION_GUIDE.md for detailed usage examples and API reference
