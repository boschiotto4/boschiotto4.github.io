# Routine Time Duration Configuration Guide

## Quick Start Example

**Example: 3-hour ON, 2-hour OFF, 30-min ON cycle**

### Android App
1. Open Routine tab
2. Load routines: Click **Load** button
3. Configure Routine 1:
   - ✓ Enable
   - Trigger: `> Target` (rises above 28°C)
   - Trig Temp: 28.0
   - AC Power: On
   - Mode: Cool
   - Target Temp: 28
   - Duration: 180 (minutes)
4. Configure Routine 2:
   - ✓ Enable
   - Trigger: `< Target` (drops below 26°C)
   - AC Power: Off
   - Duration: 120 (minutes)
5. Configure Routine 3:
   - ✓ Enable
   - Trigger: Any trigger (auto-activate)
   - AC Power: On
   - Mode: Cool
   - Target Temp: 24
   - Duration: 30 (minutes)
6. Click **Save** to push to ESP32
7. Click **Status** to monitor active routine

## HTTP API Reference

### Get Current Routine Status
```
GET http://192.168.5.1/api/status
```

Response includes:
```json
{
  "active_routine": 0,
  "routine_time_remaining_sec": 3541,
  ...
}
```

### Get All Routines
```
GET http://192.168.5.1/api/routine/get
```

Response:
```json
[
  {
    "en": 1,        // enabled
    "typ": 1,       // 1=rises above, 2=drops below
    "tt": 28.0,     // trigger temp
    "dur": 180,     // duration in minutes
    "p": "On",      // power
    "m": "Cool",    // mode
    "t": 28,        // target temp
    "f": "Auto",    // fan
    "v": "Off",     // swing vertical
    "h": "Off"      // swing horizontal
  },
  ...
]
```

### Set Routine Duration
```
GET http://192.168.5.1/api/routine/set?r0_dur=180&r1_dur=120&r2_dur=30
```

Full parameter template for one routine:
```
r0_en=1              # enabled (0/1)
r0_typ=1             # trigger type (1=rise, 2=drop)
r0_tt=28.0           # trigger temperature
r0_dur=180           # duration minutes
r0_p=On              # power
r0_m=Cool            # mode
r0_t=28              # target temperature
r0_f=Auto            # fan speed
r0_v=Off             # swing vertical
r0_h=Off             # swing horizontal
```

Repeat for r1_*, r2_*, etc. (up to r7_*)

## How It Works

### Temperature-Based Triggering
1. ESP32 monitors internal temperature sensor
2. When temp crosses threshold (with 1°C hysteresis), routine activates
3. Routine runs Daikin command: Power/Mode/Temp/Fan/Swing settings
4. Timer starts counting down

### Duration & Sequencing
1. While routine active, timer decrements each second
2. When duration expires (time_remaining_sec ≤ 0):
   - Routine deactivates
   - Next routine index advances
   - Look for next enabled routine trigger
3. When condition met, next routine activates
4. After routine 7, loops back to routine 0

### Auto-Deactivation
- If trigger condition no longer met → routine can't reactivate
- If routine expires → automatically transitions
- Changing routine config → resets scheduler state

## Field Descriptions

| Field | Type | Range | Description |
|-------|------|-------|-------------|
| en | int | 0-1 | Routine enabled |
| typ | int | 1-2 | 1=rises above, 2=drops below threshold |
| tt | float | 15-35 | Trigger temperature (°C) |
| dur | int | 5-1440 | Duration (minutes) |
| p | string | On/Off | Daikin power state |
| m | string | Cool/Heat/Fan/Dry/Auto | Daikin mode |
| t | int | 16-30 | Daikin target temperature |
| f | string | Auto/Quiet/Min/Med/Max | Fan speed |
| v | string | On/Off/Auto | Vertical swing |
| h | string | On/Off/Auto | Horizontal swing |

## Typical Durations
- 5-30 min: Quick test/response cycles
- 60 min: 1-hour standard blocks
- 180 min: 3-hour morning/evening patterns
- 720 min: 12-hour half-day cycles
- 1440 min: 24-hour daily patterns

## Troubleshooting

**Routine not activating:**
- Check trigger type matches current temperature direction
- Verify ESP32 time is synced (use Status → check time_valid)
- Ensure routine is enabled (en=1)
- Check temperature sensor reading in app

**Routine not transitioning:**
- Verify duration setting (dur > 0)
- Check next routine is also enabled
- Ensure next routine trigger will be met
- Monitor status for active_routine value

**Time remaining shows 0:**
- Routine is between active and next transition
- Wait a few seconds for scheduler to process
- Press Status again to refresh

## Notes
- Routines persist in NVS (survives ESP32 restart)
- Time synchronization: SNTP or manual epoch from Android
- Scheduler checks every 1 second (±1 sec accuracy)
- All times in UTC (no timezone conversion)
