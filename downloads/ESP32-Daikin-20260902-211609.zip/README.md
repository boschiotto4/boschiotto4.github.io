﻿# ESP32 Daikin AC Controller - Release 20260902-211609

## Contents

- **firmware/** - ESP32 firmware binaries
  - firmware.bin - Main firmware (flash at 0x10000)
  - bootloader.bin - ESP32 bootloader (flash at 0x1000)
  - partitions.bin - Partition table (flash at 0x8000)
  
- **DaikinESP32Controller.apk** - Android controller app

- **ANDROID_ESP32_SETUP.md** - Setup and usage instructions

## Quick Start

### Flash ESP32 Firmware

Using esptool.py:
```
esptool.py --chip esp32 --port COM3 --baud 460800 write_flash -z 0x1000 firmware/bootloader.bin 0x8000 firmware/partitions.bin 0x10000 firmware/firmware.bin
```

Or use PlatformIO from the source repository.

### Install Android App

1. Transfer DaikinESP32Controller.apk to your Android device
2. Enable "Install from unknown sources" in device settings
3. Install the APK
4. Connect to ESP32-DAIKIN Wi-Fi network (password: 12345678)
5. Open the app (host should be 192.168.4.1)

## ESP32 Control AP

- SSID: ESP32-DAIKIN
- Password: 12345678
- IP: 192.168.4.1

## Documentation

See ANDROID_ESP32_SETUP.md for complete setup and API documentation.
